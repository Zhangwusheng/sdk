//
//  GlobalConfig.h
//  aprios
//
//  Created by zhangwusheng on 15/8/22.
//  Copyright (c) 2015年 adw. All rights reserved.
//

#ifndef aprios_GlobalConfig_h
#define aprios_GlobalConfig_h

#define DATA_SERDER_KV  1
#define DATA_SERDER_PB  2
#define DATA_SERDER_CUR DATA_SERDER_KV

#endif
