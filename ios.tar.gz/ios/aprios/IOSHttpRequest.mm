#include "IOSHttpRequest.h"

bool IOSHttpRequest::execute()
{
    return true;
}